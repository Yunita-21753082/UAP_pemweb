<?php
  require('koneksi2.php');
 
  // Display data
    $id = $_GET['id'];
    $sql = 'SELECT * FROM mahasiswa WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $id]);
    $data = $stmt->fetch();
    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View</title>
	<h1>Data Mahasiswa</h1>
    <body>

<table>
  <tr>
    <td>Nama</td>
    <td>:</td>
    <td>
      <?= $data['nama'] ?>
    </td>
  </tr>
  <tr>
    <td>jenis kelamin</td>
    <td>:</td>
    <td><label>
     <?= $data['jenis_kelamin'] ?>
    </label></td>
  </tr>
  <tr>
    <td>Jurusan</td>
    <td>:</td>
    <td><label>
     <?= $data['jurusan'] ?>
    </label></td>
  </tr>
  <tr>
    <td>Prodi</td>
    <td>:</td>
    <td><label>
		<?= $data['program_studi'] ?>
    </label></td>
  </tr>
  <tr>
    <td> </td>
    <td> </td>
    <td></td>
  </tr>
  <tr>
    <td> </td>
    <td> </td>
    <td>
	<button onclick="history.go(-1)">Kembali</button>
	
	</td>
  </tr>
  </table>
  </form>
  </body>
</html>