<?php
  require('koneksi2.php');
 
  // Update data
  if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $jurusan = $_POST['jurusan'];
    $program_studi = $_POST['program_studi'];
 
    $sql = 'UPDATE mahasiswa SET nama = :nama, jenis_kelamin = :jenis_kelamin, jurusan = :jurusan, program_studi = :program_studi WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':nama' => $nama, ':jenis_kelamin' => $jenis_kelamin, ':jurusan' => $jurusan, ':program_studi' => $program_studi, ':id' => $id]);
    header("location:datamahasiswa.php");
  }
 
  // Menampilkan data yang akan diupdate
  if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = 'SELECT * FROM mahasiswa WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $id]);
    $data = $stmt->fetch();
  }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
	<h1>Update Data Mahasiswa</h1>
    <body>
<form action="" method="post">
 <input type="hidden" name="id" value="<?= $data['id'] ?>">
<table>
  <tr>
    <td>Nama</td>
    <td>:</td>
    <td>
      <input type="text" name="nama" id="nama" value="<?= $data['nama'] ?>">
    </td>
  </tr>
  <tr>
    <td>jenis kelamin</td>
    <td>:</td>
    <td><label>
     <input type="text" name="jenis_kelamin" id="jenis_kelamin" value="<?= $data['jenis_kelamin'] ?>">
    </label></td>
  </tr>
  <tr>
    <td>Jurusan</td>
    <td>:</td>
    <td><label>
      <input type="text" name="jurusan" id="jurusan" value="<?= $data['jurusan'] ?>">
    </label></td>
  </tr>
  <tr>
    <td>Prodi</td>
    <td>:</td>
    <td><label>
		<input type="text" name="program_studi" id="program_studi" value="<?= $data['program_studi'] ?>">
    </label></td>
  </tr>
  <tr>
    <td> </td>
    <td> </td>
    <td><input type="submit" name="submit" value="Update"></td>
  </tr>
  </table>
  </form>
  </body>
</html>