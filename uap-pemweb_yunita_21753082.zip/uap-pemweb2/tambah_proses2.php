<?php
// Panggil file koneksi.php
include "koneksi2.php";

// Ambil data dari form
$nama = $_POST['nama'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$jurusan = $_POST['jurusan'];
$program_studi = $_POST['program_studi'];

// Buat query tambah data
$query = "INSERT INTO mahasiswa (nama, jenis_kelamin, jurusan, program_studi) VALUES (?, ?, ?, ?)";

// Persiapkan statement
$stmt = $pdo->prepare($query);

// Bind data
$stmt->bindParam(1, $nama);
$stmt->bindParam(2, $jenis_kelamin);
$stmt->bindParam(3, $jurusan);
$stmt->bindParam(4, $program_studi);

// Jalankan query
$stmt->execute();

// Redirect ke index.php
header("location:datamahasiswa.php");

// Tutup koneksi
$conn = null;
?>
