<?php
  require('koneksi2.php');
 
  // Delete data
  if (isset($_POST['submit'])) {
    $id = $_GET['id'];
    $sql = 'DELETE FROM db_mahasiswa WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $id]);
    header("location:datamahasiswa.php");
  }
?>