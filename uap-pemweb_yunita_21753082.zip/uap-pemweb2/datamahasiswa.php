<?php
require('koneksi2.php');
    
$select = $pdo->query('SELECT * FROM mahasiswa'); 

?>
<html>
<head>
    <title>Lihat Data</title>
</head>
<body>
<h1>Daftar Calon Mahasiswa Baru</h1>
<a href='tambah.php?id=$id' class="isi"><input type='button' value='Tambah Data'></a><br/>
    <table style="font-size:11px;font-family:'arial';text-align:center;" border='1' width="80%" cellpadding="5" cellspacing="0" align='center' >
    <tr><th>id</th>
	<th>Nama</th>
    <th>Jenis Kelamin</th>
    <th>Jurusan</th>
    <th>Prodi</th>
    <th>Action</th></tr>
<?php
		$noUrut =1;
    while($select_result  =$select->fetch())
    {
        $id = $select_result['id'];
        $Nama = $select_result['nama'];
        $Jenis_Kelamin = $select_result['jenis_kelamin'];
        $Jurusan    = $select_result['jurusan'];
        $Prodi    = $select_result['program_studi']; 
        echo" <tr><td>$id</td><td>$Nama</td><td>$Jenis_Kelamin</td><td>$Jurusan</td><td>$Prodi</td>
    <td>
    <a href='update.php?id=$id'><input type='button' value='Update'></a>
    <a href='del.php?id=$id'><input type='button' value='Delete'></a>
    <a href='view.php?id=$id'><input type='button' value='View'></a>	
    </td>
    </tr>";

    }

?>
</table>
</body>
</html>