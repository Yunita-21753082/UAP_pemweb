<?php
// Konfigurasi koneksi ke database
$host = 'localhost';
$user = 'root';
$pass = '';
$database = 'db_mahasiswa';
 
$options = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_EMULATE_PREPARES => false
);
 
// Buat koneksi ke database
$pdo = new PDO("mysql:host=$host;dbname=$database", $user, $pass, $options);
?>