<form action="tambah_proses2.php" method="post">
    <label for="nama">Nama:</label><br>
    <input type="text" id="nama" name="nama"><br>
    <label for="jenis_kelamin">Jenis Kelamin:</label><br>
    <input type="radio" id="jenis_kelamin" name="jenis_kelamin" value="Laki-laki">Laki-laki
    <input type="radio" id="jenis_kelamin" name="jenis_kelamin" value="Perempuan">Perempuan<br>
    <label for="jurusan">Jurusan:</label><br>
    <input type="text" id="jurusan" name="jurusan"><br>
    <label for="program_studi">Program Studi:</label><br>
    <input type="text" id="program_studi" name="program_studi"><br><br>
    <input type="submit" value="Submit">
</form> 
